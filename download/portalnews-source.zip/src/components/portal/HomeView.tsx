'use client'
import { useEffect, useState, Fragment } from 'react'
import { useAppStore } from '@/lib/store'
import { ArticleCard } from './ArticleCard'
import { AdBanner } from './AdBanner'
import { HeroSlideshow } from './HeroSlideshow'
import { cn } from '@/lib/utils'
import { Eye, ArrowRight, Sparkles, Flame, Newspaper, ChevronRight, Megaphone, Mail, CheckCircle2 } from 'lucide-react'

interface HomeData {
  slide: { config: any; posts: any[] }
  hero: any | null
  subHero: any[]
  latest: any[]
  mostRead: any[]
  byCategory: Record<string, any[]>
  categories: Array<{ id: string; slug: string; name: string; color: string; description?: string }>
}

export function HomeView({ categories: propCategories }: { categories: any[] }) {
  const { setView, user } = useAppStore()
  const [data, setData] = useState<HomeData | null>(null)
  const [loading, setLoading] = useState(true)
  const [newsletterSubmitted, setNewsletterSubmitted] = useState(false)

  useEffect(() => {
    fetch('/api/home')
      .then(r => r.json())
      .then(d => setData(d))
      .catch(e => console.error('Home load error:', e))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="news-container py-12">
      <div className="animate-pulse space-y-6">
        <div className="h-96 bg-zinc-200 rounded-lg" />
        <div className="grid grid-cols-3 gap-4">{[1,2,3].map(i => <div key={i} className="h-64 bg-zinc-200 rounded" />)}</div>
      </div>
    </div>
  )

  if (!data) return (
    <div className="news-container py-12 text-center text-zinc-500">
      Erro ao carregar notícias. <button onClick={() => window.location.reload()} className="text-primary underline">Recarregar</button>
    </div>
  )

  const { slide, hero: heroPost, subHero: subHeroPosts, latest, mostRead, byCategory } = data
  // Use categories from API (more reliable), fallback to propCategories
  const categories = data.categories?.length ? data.categories : propCategories

  return (
    <div className="animate-fade-in">
      {/* === SLIDE BANNER NO TOPO === */}
      {slide?.config && slide.posts.length > 0 && (
        <div className="news-container pt-4">
          <HeroSlideshow config={slide.config} posts={slide.posts} />
        </div>
      )}

      {/* === HERO + 4 SUB-HERO (magazine layout) === */}
      {heroPost && (
        <section className="news-container py-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 lg:gap-6">
            <div className="lg:col-span-2">
              <ArticleCard post={heroPost} variant="hero" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
              {subHeroPosts.slice(0, 4).map(p => (
                <ArticleCard key={p.id} post={p} variant="compact" />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* === AD HOME_MIDDLE === */}
      <section className="news-container pb-2">
        <AdBanner placement="HOME_MIDDLE" variant="full" />
      </section>

      {/* === ÚLTIMAS NOTÍCIAS + SIDEBAR STICKY === */}
      <section className="news-container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Coluna principal (2/3) */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6 pb-3 border-b-2 border-zinc-100">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-lg bg-primary text-white flex items-center justify-center">
                  <Newspaper className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-zinc-900 text-xl sm:text-2xl" style={{ fontWeight: 600 }}>Últimas Notícias</h2>
                  <p className="text-xs text-zinc-500 mt-0.5">Atualizado em tempo real</p>
                </div>
              </div>
              <button
                onClick={() => setView({ name: 'home' })}
                className="hidden sm:flex items-center gap-1 text-xs text-primary hover:text-blue-700 transition-colors"
                style={{ fontWeight: 500 }}
              >
                Ver arquivo <ChevronRight className="h-3 w-3" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {latest.slice(0, 8).map((p, i) => (
                <Fragment key={p.id}>
                  <ArticleCard post={p} variant="standard" showExcerpt />
                  {(i + 1) % 4 === 0 && i < 7 && (
                    <div className="sm:col-span-2">
                      <AdBanner placement="HOME_INFEED" variant="full" />
                    </div>
                  )}
                </Fragment>
              ))}
            </div>
          </div>

          {/* === SIDEBAR STICKY (1/3) === */}
          <aside className="lg:col-span-1">
            <div className="sticky top-32 space-y-5">
              {/* Mais Lidas */}
              <div className="bg-white border border-zinc-100 rounded-2xl p-5 shadow-sm">
                <div className="flex items-center gap-2.5 mb-4">
                  <div className="h-5 w-1 rounded-full bg-primary" />
                  <h3 className="text-zinc-900 text-base" style={{ fontWeight: 600 }}>Mais Lidas</h3>
                  <Flame className="h-4 w-4 text-orange-500 ml-auto" />
                </div>
                <div className="space-y-3">
                  {mostRead.slice(0, 5).map((p, i) => (
                    <div
                      key={p.id}
                      className="flex gap-3 items-start group cursor-pointer"
                      onClick={() => { setView({ name: 'article', slug: p.slug }); window.scrollTo({ top: 0, behavior: 'smooth' }) }}
                    >
                      <div className="text-2xl text-zinc-200 leading-none w-8 group-hover:text-primary transition-colors font-numeric flex-shrink-0" style={{ fontWeight: 300 }}>
                        {String(i + 1).padStart(2, '0')}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-zinc-900 text-xs leading-snug line-clamp-3 group-hover:text-primary transition-colors" style={{ fontWeight: 500 }}>
                          {p.title}
                        </h4>
                        <div className="text-[11px] text-zinc-400 mt-1 flex items-center gap-1.5">
                          <span>{new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short' }).format(new Date(p.publishedAt || p.createdAt))}</span>
                          <span>·</span>
                          <span className="flex items-center gap-0.5"><Eye className="h-2.5 w-2.5" /> {p.views}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Ad Sidebar */}
              <AdBanner placement="HOME_SIDEBAR" variant="sidebar" />

              {/* CTA Ganhe pontos — apenas se não logado */}
              {!user && (
                <div className="bg-gradient-to-br from-primary to-blue-700 text-white rounded-2xl p-5 shadow-sm">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="h-5 w-5" />
                    <h3 className="text-base" style={{ fontWeight: 600 }}>Ganhe pontos lendo!</h3>
                  </div>
                  <p className="text-xs text-white/90 mb-3 font-light">
                    Cadastre-se grátis e acumule pontos para anúncios grátis.
                  </p>
                  <div className="grid grid-cols-3 gap-1.5 mb-3 text-center">
                    <div className="bg-white/10 rounded p-1.5">
                      <div className="text-amber-300 text-xs font-numeric" style={{ fontWeight: 700 }}>+10</div>
                      <div className="text-[8px] text-blue-100">por notícia</div>
                    </div>
                    <div className="bg-white/10 rounded p-1.5">
                      <div className="text-amber-300 text-xs font-numeric" style={{ fontWeight: 700 }}>+5</div>
                      <div className="text-[8px] text-blue-100">por reação</div>
                    </div>
                    <div className="bg-white/10 rounded p-1.5">
                      <div className="text-amber-300 text-xs font-numeric" style={{ fontWeight: 700 }}>+30</div>
                      <div className="text-[8px] text-blue-100">check-in</div>
                    </div>
                  </div>
                  <button
                    onClick={() => setView({ name: 'register' })}
                    className="bg-white text-primary px-3 py-2 rounded-lg text-xs hover:bg-blue-50 w-full transition-colors"
                    style={{ fontWeight: 600 }}
                  >
                    Criar conta grátis
                  </button>
                </div>
              )}

              {/* CTA Anuncie aqui persistente */}
              <div className="bg-gradient-to-br from-emerald-50 to-blue-50 border border-emerald-200 rounded-2xl p-5 text-center">
                <div className="bg-emerald-500 text-white h-9 w-9 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Megaphone className="h-4 w-4" />
                </div>
                <h3 className="text-zinc-900 text-sm mb-1" style={{ fontWeight: 600 }}>Anuncie no Portal</h3>
                <p className="text-xs text-zinc-500 mb-3">Alcance milhares de leitores. Use créditos ou assine um plano.</p>
                <button
                  onClick={() => setView({ name: 'store' })}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs py-2 rounded-lg transition-colors flex items-center justify-center gap-1"
                  style={{ fontWeight: 600 }}
                >
                  <Sparkles className="h-3 w-3" /> Quero Anunciar <ArrowRight className="h-3 w-3" />
                </button>
              </div>

              {/* CTA Plano Premium */}
              <div className="bg-gradient-to-br from-purple-600 to-blue-600 text-white rounded-2xl p-5 text-center">
                <div className="text-xl mb-1">👑</div>
                <h3 className="text-sm mb-1" style={{ fontWeight: 600 }}>Plano Premium</h3>
                <p className="text-xs text-blue-100 mb-3">Anúncios ilimitados, badge verificado.</p>
                <button
                  onClick={() => setView({ name: 'plans' })}
                  className="w-full bg-white text-purple-700 text-xs py-2 rounded-lg hover:bg-purple-50 transition-colors flex items-center justify-center gap-1"
                  style={{ fontWeight: 600 }}
                >
                  Ver Planos <ArrowRight className="h-3 w-3" />
                </button>
              </div>

              {/* Newsletter mini */}
              <div className="bg-white border border-zinc-100 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-3">
                  <div className="h-8 w-8 rounded-lg bg-primary text-white flex items-center justify-center">
                    <Mail className="h-4 w-4" />
                  </div>
                  <div>
                    <h3 className="text-zinc-900 text-sm" style={{ fontWeight: 600 }}>Receba notícias</h3>
                    <p className="text-[10px] text-zinc-500">No seu email, todo dia</p>
                  </div>
                </div>
                {newsletterSubmitted ? (
                  <div className="text-center py-3 text-xs text-emerald-700 bg-emerald-50 rounded-lg flex items-center justify-center gap-1">
                    <CheckCircle2 className="h-4 w-4" /> Inscrição confirmada!
                  </div>
                ) : (
                  <form onSubmit={async (e) => {
                    e.preventDefault()
                    const form = e.target as HTMLFormElement
                    const email = (form.elements.namedItem('email') as HTMLInputElement).value
                    if (!email) return
                    try {
                      await fetch('/api/newsletter', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ email, source: 'home_sidebar' }),
                      })
                      setNewsletterSubmitted(true)
                      ;(form.elements.namedItem('email') as HTMLInputElement).value = ''
                    } catch {}
                  }} className="space-y-2">
                    <input name="email" type="email" placeholder="seu@email.com" className="w-full text-xs px-3 py-2 rounded-lg border border-zinc-200 focus:border-primary focus:outline-none" required />
                    <button type="submit" className="w-full bg-primary text-white text-xs py-2 rounded-lg hover:bg-blue-700 transition-colors" style={{ fontWeight: 600 }}>
                      Quero Receber
                    </button>
                  </form>
                )}
              </div>
            </div>
          </aside>
        </div>
      </section>

      {/* === BLOCOS POR CATEGORIA === */}
      {categories.slice(0, 6).map((cat, idx) => {
        const posts = byCategory[cat.slug] || []
        if (posts.length === 0) return null
        return (
          <section key={cat.id} className="news-container pb-12">
            <div className="flex items-center justify-between mb-6 pb-3 border-b-2 border-zinc-100">
              <div className="flex items-center gap-3">
                <div className={cn('h-9 w-9 rounded-lg flex items-center justify-center text-white', `bg-${cat.color || 'slate'}-500`)}>
                  <Flame className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-zinc-900 text-xl sm:text-2xl" style={{ fontWeight: 600 }}>{cat.name}</h2>
                  {cat.description && <p className="text-xs text-zinc-500 mt-0.5 line-clamp-1">{cat.description}</p>}
                </div>
              </div>
              <button
                onClick={() => setView({ name: 'category', slug: cat.slug })}
                className="flex items-center gap-1 text-xs sm:text-sm text-primary hover:text-blue-700 transition-colors flex-shrink-0"
                style={{ fontWeight: 500 }}
              >
                Ver mais <ArrowRight className="h-3 w-3" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {posts.slice(0, 4).map((p, i) => (
                <Fragment key={p.id}>
                  <ArticleCard post={p} variant="standard" />
                  {i === 1 && (
                    <AdBanner placement="HOME_INFEED" variant="full" />
                  )}
                </Fragment>
              ))}
            </div>
            {(idx === 1 || idx === 3) && (
              <div className="mt-6">
                <AdBanner placement="HOME_MIDDLE" variant="full" />
              </div>
            )}
          </section>
        )
      })}

      {/* === CTA FINAL: 2 cards === */}
      <section className="news-container pb-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-gradient-to-br from-amber-500 to-purple-600 text-white rounded-2xl p-6">
            <div className="text-2xl mb-2">💼</div>
            <h3 className="text-lg mb-1" style={{ fontWeight: 600 }}>É profissional liberal?</h3>
            <p className="text-sm text-white/90 mb-3">Apareça nas matérias da sua área de atuação. A partir de R$ 49/mês.</p>
            <button
              onClick={() => setView({ name: 'plans' })}
              className="bg-white text-purple-700 px-4 py-2 rounded-lg text-sm hover:bg-purple-50 transition-colors"
              style={{ fontWeight: 600 }}
            >
              Ver planos profissionais
            </button>
          </div>
          <div className="bg-gradient-to-br from-emerald-500 to-blue-600 text-white rounded-2xl p-6">
            <div className="text-2xl mb-2">🏪</div>
            <h3 className="text-lg mb-1" style={{ fontWeight: 600 }}>Tem um negócio?</h3>
            <p className="text-sm text-white/90 mb-3">Perfil público com catálogo, WhatsApp e mapa. A partir de R$ 29/mês.</p>
            <button
              onClick={() => setView({ name: 'plans' })}
              className="bg-white text-blue-700 px-4 py-2 rounded-lg text-sm hover:bg-blue-50 transition-colors"
              style={{ fontWeight: 600 }}
            >
              Ver planos para empresas
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}
